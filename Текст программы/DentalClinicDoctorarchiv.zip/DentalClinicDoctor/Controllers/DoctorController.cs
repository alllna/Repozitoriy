﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DentalClinicDoctor.Models;
using DentalClinicDoctor.Services;
using System.Text;

namespace DentalClinicDoctor.Controllers
{
    [Authorize]
    public class DoctorController : Controller
    {
        private readonly DoctorService _doctorService;

        public DoctorController(DoctorService doctorService)
        {
            _doctorService = doctorService;
        }

        private int GetCurrentDoctorId()
        {
            return int.Parse(User.FindFirst("DoctorId")?.Value ?? "0");
        }

        public IActionResult Index()
        {
            var doctorId = GetCurrentDoctorId();
            var doctor = _doctorService.GetDoctorInfo(doctorId);
            var todayAppointments = _doctorService.GetTodayAppointments(doctorId);

            var viewModel = new TodayPatientsViewModel
            {
                Doctor = doctor,
                TodayAppointments = todayAppointments,
                TotalAppointments = todayAppointments.Count,
                CompletedAppointments = todayAppointments.Count(a => a.Status == "completed"),
                PendingAppointments = todayAppointments.Count(a => a.Status == "scheduled")
            };

            return View(viewModel);
        }

        public IActionResult Schedule()
        {
            var doctorId = GetCurrentDoctorId();
            var startDate = DateTime.Today;
            var schedule = _doctorService.GetDoctorSchedule(doctorId, startDate);

            // Группировка по дням
            var groupedSchedule = schedule
                .GroupBy(a => a.Date)
                .OrderBy(g => g.Key)
                .ToDictionary(g => g.Key, g => g.ToList());

            // Возвращаем словарь напрямую, без дополнительной модели
            return View(groupedSchedule);
        }

        public IActionResult Patients()
        {
            var doctorId = GetCurrentDoctorId();
            var patients = _doctorService.GetDoctorPatients(doctorId);
            return View(patients);
        }

        public IActionResult PatientDetails(int id)
        {
            var doctorId = GetCurrentDoctorId();
            var patientInfo = _doctorService.GetDoctorPatients(doctorId).FirstOrDefault(p => p.PatientId == id);
            if (patientInfo == null)
                return NotFound();

            var history = _doctorService.GetPatientHistory(doctorId, id);
            var medicalRecords = _doctorService.GetMedicalRecords(doctorId, id);

            ViewBag.Patient = patientInfo;
            ViewBag.History = history;

            return View(medicalRecords);
        }

        [HttpPost]
        public IActionResult SaveMedicalRecord([FromBody] MedicalRecordModel record)
        {
            var doctorId = GetCurrentDoctorId();
            var result = _doctorService.SaveMedicalRecord(record, doctorId);
            return Json(new { success = result });
        }

        [HttpPost]
        public IActionResult CompleteAppointment(int appointmentId)
        {
            var doctorId = GetCurrentDoctorId();
            var result = _doctorService.MarkAppointmentCompleted(appointmentId, doctorId);
            return Json(new { success = result });
        }

        public IActionResult Reviews()
        {
            var doctorId = GetCurrentDoctorId();
            var doctor = _doctorService.GetDoctorInfo(doctorId);
            var reviews = _doctorService.GetDoctorReviews(doctorId);

            var viewModel = new DoctorRatingViewModel
            {
                Doctor = doctor,
                Reviews = reviews,
                AverageGrade = doctor?.Rating ?? 0,
                HeartsCount = doctor?.TotalHearts ?? 0
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult AddRecommendation(int patientId, string recommendation)
        {
            var doctorId = GetCurrentDoctorId();
            var result = _doctorService.AddRecommendation(doctorId, patientId, recommendation);
            return Json(new { success = result });
        }

        public IActionResult ScheduleCalendar()
        {
            var doctorId = GetCurrentDoctorId();
            var schedule = _doctorService.GetDoctorSchedule(doctorId, DateTime.Today.AddDays(-7));
            return Json(schedule.Select(a => new
            {
                title = $"{a.PatientName} - {a.ServiceName}",
                start = $"{a.Date:yyyy-MM-dd}T{a.StartTime}",
                status = a.Status
            }));
        }

        [HttpGet]
        public async Task<IActionResult> GetPatientHistory(int patientId)
        {
            var doctorId = GetCurrentDoctorId();
            var history = _doctorService.GetPatientHistory(doctorId, patientId);

            var result = history.Select(h => new
            {
                h.Date,
                h.StartTime,
                h.ServiceName,
                h.Price,
                h.Status
            });

            return Json(result);
        }

        // Экспорт в CSV с корректной кодировкой для VS Code и Excel
        [HttpPost]
        public IActionResult ExportReviews()
        {
            try
            {
                var doctorId = GetCurrentDoctorId();
                var reviews = _doctorService.GetDoctorReviews(doctorId);

                var sb = new StringBuilder();

                // Добавляем BOM для UTF-8 (нужен для корректного отображения кириллицы)
                sb.AppendLine("Пациент;Оценка;Дата;Отзыв");

                foreach (var review in reviews)
                {
                    var date = review.CreateDate.ToString("dd.MM.yyyy");

                    // Не экранируем сильно, просто заменяем проблемные символы
                    var patientName = (review.PatientName ?? "Аноним").Replace(";", ",").Replace("\"", "'");
                    var comment = (review.Comment ?? "Без комментария")
                        .Replace(";", ",")
                        .Replace("\"", "'")
                        .Replace("\n", " ")
                        .Replace("\r", " ");

                    sb.AppendLine($"{patientName};{review.Grade};{date};{comment}");
                }

                // Используем UTF-8 с BOM для корректной кириллицы
                var utf8WithBom = new UTF8Encoding(true);
                var bytes = utf8WithBom.GetBytes(sb.ToString());
                var fileName = $"reviews_{DateTime.Now:yyyyMMdd_HHmmss}.csv";

                return File(bytes, "text/csv; charset=utf-8", fileName);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        // Экспорт в Excel через HTML (работает 100%)
        [HttpPost]
        public IActionResult ExportToExcel()
        {
            try
            {
                var doctorId = GetCurrentDoctorId();
                var reviews = _doctorService.GetDoctorReviews(doctorId);

                var sb = new StringBuilder();

                // HTML таблица для Excel
                sb.AppendLine("<html>");
                sb.AppendLine("<head>");
                sb.AppendLine("<meta charset='UTF-8'>");
                sb.AppendLine("<title>Отзывы пациентов</title>");
                sb.AppendLine("<style>");
                sb.AppendLine("th { background-color: #4CAF50; color: white; }");
                sb.AppendLine("td, th { border: 1px solid #ddd; padding: 8px; }");
                sb.AppendLine("table { border-collapse: collapse; width: 100%; }");
                sb.AppendLine("</style>");
                sb.AppendLine("</head>");
                sb.AppendLine("<body>");
                sb.AppendLine("<h2>Отзывы пациентов</h2>");
                sb.AppendLine("<table>");
                sb.AppendLine("<tr>");
                sb.AppendLine("<th>Пациент</th>");
                sb.AppendLine("<th>Оценка</th>");
                sb.AppendLine("<th>Дата</th>");
                sb.AppendLine("<th>Отзыв</th>");
                sb.AppendLine("</tr>");

                foreach (var review in reviews)
                {
                    sb.AppendLine("<tr>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(review.PatientName ?? "Аноним")}</td>");
                    sb.AppendLine($"<td style='text-align: center;'>{review.Grade} ★</td>");
                    sb.AppendLine($"<td>{review.CreateDate:dd.MM.yyyy}</td>");
                    sb.AppendLine($"<td>{System.Net.WebUtility.HtmlEncode(review.Comment ?? "Без комментария")}</td>");
                    sb.AppendLine("</tr>");
                }

                sb.AppendLine("</table>");
                sb.AppendLine($"<p><strong>Всего отзывов: {reviews.Count}</strong></p>");
                sb.AppendLine("</body>");
                sb.AppendLine("</html>");

                var bytes = Encoding.UTF8.GetBytes(sb.ToString());
                var fileName = $"reviews_{DateTime.Now:yyyyMMdd_HHmmss}.xls";

                // Отправляем как Excel файл
                return File(bytes, "application/vnd.ms-excel", fileName);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }



        // Вспомогательный метод для экранирования CSV полей
        private string EscapeCsvField(string field)
        {
            if (string.IsNullOrEmpty(field)) return string.Empty;

            // Если поле содержит точку с запятой, кавычку или перевод строки
            if (field.Contains(';') || field.Contains('"') || field.Contains('\n') || field.Contains('\r'))
            {
                // Экранируем кавычки
                field = field.Replace("\"", "\"\"");
                // Оборачиваем в кавычки
                return $"\"{field}\"";
            }

            return field;
        }
    }
}