﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using DentalClinicDoctor.Models;
using DentalClinicDoctor.Services;
using System.Security.Claims;

namespace DentalClinicDoctor.Controllers
{
    public class AccountController : Controller
    {
        private readonly DoctorService _doctorService;

        public AccountController(DoctorService doctorService)
        {
            _doctorService = doctorService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Doctor");
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var doctor = _doctorService.Login(model.Login, model.Password);

                if (doctor != null)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, doctor.FullName),
                        new Claim(ClaimTypes.NameIdentifier, doctor.DoctorId.ToString()),
                        new Claim("DoctorId", doctor.DoctorId.ToString()),
                        new Claim("Specialty", doctor.Specialty)
                    };

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);

                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                    return RedirectToAction("Index", "Doctor");
                }

                ModelState.AddModelError("", "Неверный логин или пароль");
            }
            return View(model);
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
    }
}