﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Data.SqlClient;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class ReviewsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ReviewsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public IActionResult CreateReview([FromBody] ReviewRequest request, [FromQuery] int patientId)
        {
            try
            {
                if (request == null)
                {
                    return Ok(new { success = false, message = "Данные не переданы" });
                }

                if (patientId == 0)
                {
                    return Ok(new { success = false, message = "Пациент не авторизован" });
                }

                if (request.grade < 1 || request.grade > 5)
                {
                    return Ok(new { success = false, message = "Оценка должна быть от 1 до 5" });
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        INSERT INTO Rewiews (patient_ID_int, doctor_ID_int, grade_int, comment_varchar, create_at_datetime)
                        VALUES (@patientId, @doctorId, @grade, @comment, GETDATE());
                        SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        cmd.Parameters.AddWithValue("@doctorId", request.doctorId);
                        cmd.Parameters.AddWithValue("@grade", request.grade);
                        cmd.Parameters.AddWithValue("@comment", string.IsNullOrEmpty(request.comment) ? (object)DBNull.Value : request.comment);

                        int newId = Convert.ToInt32(cmd.ExecuteScalar());

                        return Ok(new { success = true, message = "Отзыв успешно добавлен", reviewId = newId });
                    }
                }
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }
    }

    public class ReviewRequest
    {
        public int doctorId { get; set; }
        public int grade { get; set; }
        public string comment { get; set; }
    }
}