﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Data.SqlClient;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class DoctorsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public DoctorsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetDoctors()
        {
            var doctors = new List<object>();
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                    SELECT d.Doctor_ID_int, 
                           d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as FullName,
                           d.specialty_varchar as Specialty,
                           ISNULL(AVG(CAST(r.grade_int AS FLOAT)), 0) as Rating,
                           COUNT(DISTINCT r.Review_ID_int) as ReviewCount,
                           (SELECT COUNT(*) FROM Rewiews WHERE doctor_ID_int = d.Doctor_ID_int AND grade_int >= 4) as HeartsCount
                    FROM Doctors d
                    LEFT JOIN Rewiews r ON d.Doctor_ID_int = r.doctor_ID_int
                    GROUP BY d.Doctor_ID_int, d.surname_varchar, d.name_varchar, 
                             d.middle_name_varchar, d.specialty_varchar";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        doctors.Add(new
                        {
                            id = reader.GetInt32(0),
                            fullName = reader.GetString(1),
                            specialty = reader.GetString(2),
                            rating = reader.GetDouble(3),
                            reviewCount = reader.GetInt32(4),
                            heartsCount = reader.GetInt32(5)
                        });
                    }
                }
            }

            return Ok(doctors);
        }

        [HttpGet("{id}")]
        public IActionResult GetDoctor(int id)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                    SELECT d.Doctor_ID_int, 
                           d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as FullName,
                           d.specialty_varchar as Specialty,
                           d.photo_url_varchar as PhotoUrl,
                           d.description,
                           ISNULL(AVG(CAST(r.grade_int AS FLOAT)), 0) as Rating,
                           COUNT(DISTINCT r.Review_ID_int) as ReviewCount,
                           (SELECT COUNT(*) FROM Rewiews WHERE doctor_ID_int = d.Doctor_ID_int AND grade_int >= 4) as HeartsCount
                    FROM Doctors d
                    LEFT JOIN Rewiews r ON d.Doctor_ID_int = r.doctor_ID_int
                    WHERE d.Doctor_ID_int = @id
                    GROUP BY d.Doctor_ID_int, d.surname_varchar, d.name_varchar, 
                             d.middle_name_varchar, d.specialty_varchar, d.photo_url_varchar, d.description";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return Ok(new
                            {
                                id = reader.GetInt32(0),
                                fullName = reader.GetString(1),
                                specialty = reader.GetString(2),
                                photoUrl = reader.IsDBNull(3) ? null : reader.GetString(3),
                                description = reader.IsDBNull(4) ? null : reader.GetString(4),
                                rating = reader.GetDouble(5),
                                reviewCount = reader.GetInt32(6),
                                heartsCount = reader.GetInt32(7)
                            });
                        }
                    }
                }
            }

            return NotFound();
        }

        [HttpGet("{id}/reviews")]
        public IActionResult GetDoctorReviews(int id)
        {
            var reviews = new List<object>();
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
            SELECT r.Review_ID_int,
                   p.surname_varchar + ' ' + p.name_varchar as PatientName,
                   r.grade_int,
                   r.comment_varchar,
                   r.create_at_datetime
            FROM Rewiews r
            INNER JOIN Patient p ON r.patient_ID_int = p.Patient_ID_int
            WHERE r.doctor_ID_int = @doctorId
            ORDER BY r.create_at_datetime DESC";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reviews.Add(new
                            {
                                id = reader.GetInt32(0),
                                patientName = reader.GetString(1),
                                grade = reader.GetInt32(2),
                                comment = reader.IsDBNull(3) ? null : reader.GetString(3),
                                createdAt = reader.GetDateTime(4)
                            });
                        }
                    }
                }
            }

            return Ok(reviews);
        }



    }
}