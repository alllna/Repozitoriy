﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Text;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class AppointmentsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public AppointmentsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // СОЗДАНИЕ ЗАПИСИ - ID из URL
        [HttpPost]
        public IActionResult CreateAppointment([FromBody] AppointmentRequest request, [FromQuery] int patientId)
        {
            try
            {
                Console.WriteLine($"CreateAppointment - patientId from query: {patientId}");

                if (request == null)
                {
                    return Ok(new { success = false, message = "Данные не переданы" });
                }

                if (patientId == 0)
                {
                    return Ok(new { success = false, message = "Пациент не авторизован" });
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверка, что время еще свободно
                    string checkQuery = @"
                        SELECT COUNT(*) FROM Appointments 
                        WHERE doctor_ID_int = @doctorId 
                        AND appointment_date = @date 
                        AND start_time_time = @time
                        AND status_varchar != 'cancelled'";

                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@doctorId", request.doctorId);
                        checkCmd.Parameters.AddWithValue("@date", request.date);
                        checkCmd.Parameters.AddWithValue("@time", request.time);

                        int count = (int)checkCmd.ExecuteScalar();
                        if (count > 0)
                        {
                            return Ok(new { success = false, message = "Это время уже занято" });
                        }
                    }

                    // Создание записи
                    string insertQuery = @"
                        INSERT INTO Appointments (patient_ID_int, doctor_ID_int, servicee_ID_int, 
                                                  appointment_date, start_time_time, status_varchar, created_at_datetime)
                        VALUES (@patientId, @doctorId, @serviceId, @date, @time, 'scheduled', GETDATE());
                        SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        cmd.Parameters.AddWithValue("@doctorId", request.doctorId);
                        cmd.Parameters.AddWithValue("@serviceId", request.serviceId);
                        cmd.Parameters.AddWithValue("@date", request.date);
                        cmd.Parameters.AddWithValue("@time", request.time);

                        int newId = Convert.ToInt32(cmd.ExecuteScalar());

                        return Ok(new { success = true, message = "Запись успешно создана", appointmentId = newId });
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                return Ok(new { success = false, message = $"Ошибка базы данных: {sqlEx.Message}" });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        // ПОЛУЧИТЬ ВСЕ ЗАПИСИ - ID из URL
        [HttpGet("my")]
        public IActionResult GetMyAppointments([FromQuery] int patientId)
        {
            try
            {
                Console.WriteLine($"GetMyAppointments - patientId from query: {patientId}");

                if (patientId == 0)
                {
                    return Ok(new List<object>());
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                var appointments = new List<object>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT a.Appointment_ID_int,
                               d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as DoctorName,
                               s.title_varchar as ServiceName,
                               s.price_decimal as Price,
                               a.appointment_date as Date,
                               a.start_time_time as Time,
                               a.status_varchar as Status,
                               a.notes
                        FROM Appointments a
                        INNER JOIN Doctors d ON a.doctor_ID_int = d.Doctor_ID_int
                        INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                        WHERE a.patient_ID_int = @patientId
                        ORDER BY a.appointment_date DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                appointments.Add(new
                                {
                                    id = reader.GetInt32(0),
                                    doctorName = reader.GetString(1),
                                    serviceName = reader.GetString(2),
                                    price = reader.GetDecimal(3),
                                    date = reader.GetDateTime(4),
                                    time = reader.GetTimeSpan(5).ToString(),
                                    status = reader.GetString(6),
                                    notes = reader.IsDBNull(7) ? null : reader.GetString(7)
                                });
                            }
                        }
                    }
                }

                Console.WriteLine($"Found {appointments.Count} appointments");
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return Ok(new List<object>());
            }
        }

        // ОТМЕНА ЗАПИСИ - ID из URL
        [HttpDelete("{id}")]
        public IActionResult CancelAppointment(int id, [FromQuery] int patientId)
        {
            try
            {
                Console.WriteLine($"CancelAppointment - id: {id}, patientId: {patientId}");

                if (patientId == 0)
                {
                    return Ok(new { success = false, message = "Пациент не авторизован" });
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, что запись принадлежит этому пациенту
                    string checkQuery = "SELECT COUNT(*) FROM Appointments WHERE Appointment_ID_int = @id AND patient_ID_int = @patientId";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@id", id);
                        checkCmd.Parameters.AddWithValue("@patientId", patientId);
                        int count = (int)checkCmd.ExecuteScalar();
                        if (count == 0)
                        {
                            return Ok(new { success = false, message = "Запись не найдена или не принадлежит вам" });
                        }
                    }

                    // Обновляем статус записи на 'cancelled'
                    string query = @"
                        UPDATE Appointments 
                        SET status_varchar = 'cancelled' 
                        WHERE Appointment_ID_int = @id";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            return Ok(new { success = true, message = "Запись отменена" });
                        }
                        return Ok(new { success = false, message = "Запись не найдена" });
                    }
                }
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = ex.Message });
            }
        }

        [HttpGet("booked")]
        public IActionResult GetBookedSlots([FromQuery] int doctorId, [FromQuery] string date)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                var bookedSlots = new List<object>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                SELECT start_time_time 
                FROM Appointments 
                WHERE doctor_ID_int = @doctorId 
                AND appointment_date = @date 
                AND status_varchar != 'cancelled'";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@doctorId", doctorId);
                        cmd.Parameters.AddWithValue("@date", date);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookedSlots.Add(new { time = reader.GetTimeSpan(0).ToString() });
                            }
                        }
                    }
                }

                return Ok(bookedSlots);
            }
            catch (Exception ex)
            {
                return Ok(new List<object>());
            }
        }

        [HttpGet("income-report")]
        public IActionResult GetIncomeReport([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, [FromQuery] int doctorId = 0)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                var report = new List<object>();
                decimal totalIncome = 0;
                int totalAppointments = 0;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                SELECT 
                    a.doctor_ID_int,
                    d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as DoctorName,
                    COUNT(a.Appointment_ID_int) as AppointmentsCount,
                    SUM(s.price_decimal) as TotalIncome,
                    MIN(a.appointment_date) as FirstDate,
                    MAX(a.appointment_date) as LastDate
                FROM Appointments a
                INNER JOIN Doctors d ON a.doctor_ID_int = d.Doctor_ID_int
                INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                WHERE a.appointment_date >= @startDate 
                    AND a.appointment_date <= @endDate
                    AND a.status_varchar = 'completed'
                    " + (doctorId > 0 ? "AND a.doctor_ID_int = @doctorId" : "") + @"
                GROUP BY a.doctor_ID_int, d.surname_varchar, d.name_varchar, d.middle_name_varchar
                ORDER BY TotalIncome DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);
                        if (doctorId > 0)
                            cmd.Parameters.AddWithValue("@doctorId", doctorId);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                decimal income = reader.GetDecimal(3);
                                totalIncome += income;
                                totalAppointments += reader.GetInt32(2);

                                report.Add(new
                                {
                                    doctorId = reader.GetInt32(0),
                                    doctorName = reader.GetString(1),
                                    appointmentsCount = reader.GetInt32(2),
                                    totalIncome = income,
                                    firstDate = reader.GetDateTime(4),
                                    lastDate = reader.GetDateTime(5)
                                });
                            }
                        }
                    }
                }

                return Ok(new
                {
                    success = true,
                    period = new { startDate, endDate },
                    totalIncome = totalIncome,
                    totalAppointments = totalAppointments,
                    doctorsReport = report
                });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = ex.Message });
            }
        }

        [HttpGet("export-income-csv")]
        public IActionResult ExportIncomeToCsv([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                var sb = new StringBuilder();

                // Заголовки
                sb.AppendLine("Дата;Врач;Услуга;Стоимость;Статус");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                SELECT 
                    a.appointment_date,
                    d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as DoctorName,
                    s.title_varchar as ServiceName,
                    s.price_decimal as Price,
                    a.status_varchar as Status
                FROM Appointments a
                INNER JOIN Doctors d ON a.doctor_ID_int = d.Doctor_ID_int
                INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                WHERE a.appointment_date >= @startDate AND a.appointment_date <= @endDate
                ORDER BY a.appointment_date DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                sb.AppendLine($"{reader.GetDateTime(0):dd.MM.yyyy};{reader.GetString(1)};{reader.GetString(2)};{reader.GetDecimal(3)};{reader.GetString(4)}");
                            }
                        }
                    }
                }

                var bytes = Encoding.UTF8.GetBytes(sb.ToString());
                var fileName = $"income_report_{startDate:yyyyMMdd}_{endDate:yyyyMMdd}.csv";

                return File(bytes, "text/csv; charset=utf-8", fileName);
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = ex.Message });
            }
        }

        // ============ ОТЧЁТ О РАСХОДАХ ДЛЯ ПАЦИЕНТА ============

        [HttpGet("my-expenses")]
        public IActionResult GetMyExpenses([FromQuery] int patientId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                decimal totalExpenses = 0;
                int totalAppointments = 0;
                var appointments = new List<object>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                SELECT 
                    FORMAT(a.appointment_date, 'dd.MM.yyyy') as Date,
                    d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as DoctorName,
                    s.title_varchar as ServiceName,
                    s.price_decimal as Price,
                    a.status_varchar as Status
                FROM Appointments a
                INNER JOIN Doctors d ON a.doctor_ID_int = d.Doctor_ID_int
                INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                WHERE a.patient_ID_int = @patientId
                    AND a.appointment_date >= @startDate
                    AND a.appointment_date <= @endDate
                    AND a.status_varchar = 'completed'
                ORDER BY a.appointment_date DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                decimal price = reader.GetDecimal(3);
                                totalExpenses += price;
                                totalAppointments++;

                                appointments.Add(new
                                {
                                    date = reader.GetString(0),
                                    doctorName = reader.GetString(1),
                                    serviceName = reader.GetString(2),
                                    price = price,
                                    status = reader.GetString(4)
                                });
                            }
                        }
                    }
                }

                return Ok(new
                {
                    success = true,
                    totalExpenses = totalExpenses,
                    totalAppointments = totalAppointments,
                    appointments = appointments
                });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = ex.Message });
            }
        }

        [HttpGet("export-my-expenses")]
        public IActionResult ExportMyExpenses([FromQuery] int patientId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                var sb = new StringBuilder();

                sb.AppendLine("Дата;Врач;Услуга;Стоимость (₽)");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                SELECT 
                    FORMAT(a.appointment_date, 'dd.MM.yyyy') as Date,
                    d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as DoctorName,
                    s.title_varchar as ServiceName,
                    s.price_decimal as Price
                FROM Appointments a
                INNER JOIN Doctors d ON a.doctor_ID_int = d.Doctor_ID_int
                INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                WHERE a.patient_ID_int = @patientId
                    AND a.appointment_date >= @startDate
                    AND a.appointment_date <= @endDate
                    AND a.status_varchar = 'completed'
                ORDER BY a.appointment_date DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                sb.AppendLine($"{reader.GetString(0)};{reader.GetString(1)};{reader.GetString(2)};{reader.GetDecimal(3)}");
                            }
                        }
                    }
                }

                var utf8WithBom = new UTF8Encoding(true);
                var bytes = utf8WithBom.GetBytes(sb.ToString());
                var fileName = $"my_expenses_{startDate:yyyyMMdd}_{endDate:yyyyMMdd}.csv";

                // ИСПРАВЛЕНО: возвращаем File, а не Json
                return File(bytes, "text/csv; charset=utf-8", fileName);
            }
            catch (Exception ex)
            {
                // ИСПРАВЛЕНО: возвращаем BadRequest или Ok с ошибкой
                return BadRequest(new { success = false, message = ex.Message });
            }
        }
    }

    public class AppointmentRequest
    {
        public int doctorId { get; set; }
        public int serviceId { get; set; }
        public string date { get; set; }
        public string time { get; set; }
    }
}