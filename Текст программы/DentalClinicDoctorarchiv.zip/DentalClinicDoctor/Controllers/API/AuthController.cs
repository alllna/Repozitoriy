﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public AuthController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // ВАЖНО: выбираем ВСЕХ пациентов по логину и паролю
                    string query = @"
                SELECT p.Patient_ID_int, 
                       p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as FullName,
                       p.phone_varchar, 
                       p.email_varchar,
                       u.login_varchar,
                       p.User_ID_int
                FROM Patient p
                INNER JOIN Users u ON p.User_ID_int = u.User_ID_int
                WHERE u.login_varchar = @login AND u.password_hash = @password AND u.role_ID_int = 2";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@login", request.Login);
                        cmd.Parameters.AddWithValue("@password", request.Password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int patientId = reader.GetInt32(0);
                                string fullName = reader.GetString(1);
                                string phone = reader.IsDBNull(2) ? null : reader.GetString(2);
                                string email = reader.IsDBNull(3) ? null : reader.GetString(3);
                                string login = reader.GetString(4);
                                int userId = reader.GetInt32(5);

                                return Ok(new
                                {
                                    success = true,
                                    token = Guid.NewGuid().ToString(),
                                    user = new
                                    {
                                        id = patientId,        // ← ВАЖНО: возвращаем Patient_ID_int
                                        fullName = reader.GetString(1),
                                        phone = reader.IsDBNull(2) ? null : reader.GetString(2),
                                        email = reader.IsDBNull(3) ? null : reader.GetString(3),
                                        login = reader.GetString(4)
                                    }
                                });
                            }
                        }
                    }
                }

                return Ok(new { success = false, message = "Неверный логин или пароль" });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        [HttpGet("test")]
        public IActionResult Test()
        {
            return Ok(new { success = true, message = "API работает!" });
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterRequest request)
        {
            try
            {
                if (request == null)
                {
                    return Ok(new { success = false, message = "Данные не переданы" });
                }

                // Валидация
                if (string.IsNullOrEmpty(request.Login) || string.IsNullOrEmpty(request.Password))
                {
                    return Ok(new { success = false, message = "Логин и пароль обязательны" });
                }

                if (string.IsNullOrEmpty(request.Surname) || string.IsNullOrEmpty(request.Name))
                {
                    return Ok(new { success = false, message = "Фамилия и имя обязательны" });
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверка существования логина
                    string checkQuery = "SELECT COUNT(*) FROM Users WHERE login_varchar = @login";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@login", request.Login);
                        int count = (int)checkCmd.ExecuteScalar();
                        if (count > 0)
                        {
                            return Ok(new { success = false, message = "Логин уже существует" });
                        }
                    }

                    // Создание пользователя (роль 2 = пациент)
                    string insertUserQuery = @"
                INSERT INTO Users (role_ID_int, login_varchar, password_hash, create_at) 
                VALUES (2, @login, @password, GETDATE());
                SELECT SCOPE_IDENTITY();";

                    int userId;
                    using (SqlCommand userCmd = new SqlCommand(insertUserQuery, connection))
                    {
                        userCmd.Parameters.AddWithValue("@login", request.Login);
                        userCmd.Parameters.AddWithValue("@password", request.Password);
                        userId = Convert.ToInt32(userCmd.ExecuteScalar());
                    }

                    // Создание пациента
                    string insertPatientQuery = @"
                INSERT INTO Patient (User_ID_int, surname_varchar, name_varchar, middle_name_varchar, 
                                    phone_varchar, email_varchar, birth_date_date)
                VALUES (@userId, @surname, @name, @middlename, @phone, @email, NULL);
                SELECT SCOPE_IDENTITY();";

                    int patientId;
                    using (SqlCommand patientCmd = new SqlCommand(insertPatientQuery, connection))
                    {
                        patientCmd.Parameters.AddWithValue("@userId", userId);
                        patientCmd.Parameters.AddWithValue("@surname", request.Surname);
                        patientCmd.Parameters.AddWithValue("@name", request.Name);
                        patientCmd.Parameters.AddWithValue("@middlename", string.IsNullOrEmpty(request.MiddleName) ? (object)DBNull.Value : request.MiddleName);
                        patientCmd.Parameters.AddWithValue("@phone", string.IsNullOrEmpty(request.Phone) ? (object)DBNull.Value : request.Phone);
                        patientCmd.Parameters.AddWithValue("@email", string.IsNullOrEmpty(request.Email) ? (object)DBNull.Value : request.Email);
                        patientId = Convert.ToInt32(patientCmd.ExecuteScalar());
                    }

                    return Ok(new
                    {
                        success = true,
                        message = "Регистрация успешна",
                        patientId = patientId,
                        userId = userId
                    });
                }
            }
            catch (SqlException sqlEx)
            {
                return Ok(new { success = false, message = $"Ошибка базы данных: {sqlEx.Message}" });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }
    }

    public class LoginRequest
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }

    public class RegisterRequest
    {
        public string Surname { get; set; }
        public string Name { get; set; }
        public string MiddleName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}