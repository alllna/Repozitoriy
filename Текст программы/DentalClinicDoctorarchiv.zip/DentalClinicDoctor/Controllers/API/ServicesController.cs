﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Data.SqlClient;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class ServicesController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ServicesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetServices()
        {
            var services = new List<object>();
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // ВАЖНО: таблица называется Servicees (с двумя e)
                string query = @"
                    SELECT Servicee_ID_int, 
                           title_varchar, 
                           description, 
                           price_decimal, 
                           duration_minutes_int
                    FROM Servicees";  // ← ИСПРАВЛЕНО: Servicees, а не Services

                using (SqlCommand cmd = new SqlCommand(query, connection))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        services.Add(new
                        {
                            id = reader.GetInt32(0),
                            title = reader.GetString(1),
                            description = reader.IsDBNull(2) ? null : reader.GetString(2),
                            price = reader.GetDecimal(3),
                            durationMinutes = reader.GetInt32(4)
                        });
                    }
                }
            }

            return Ok(services);
        }
    }
}