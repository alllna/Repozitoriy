﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Data.SqlClient;

namespace DentalClinicDoctor.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowAll")]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet("profile")]
        public IActionResult GetProfile([FromQuery] int patientId) // ✅ Получаем ID из URL
        {
            try
            {
                Console.WriteLine($"GetProfile - patientId: {patientId}");

                if (patientId == 0)
                {
                    return Ok(new { success = false, message = "Patient ID required" });
                }

                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT p.Patient_ID_int,
                               p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as FullName,
                               p.phone_varchar,
                               p.email_varchar,
                               u.login_varchar
                        FROM Patient p
                        INNER JOIN Users u ON p.User_ID_int = u.User_ID_int
                        WHERE p.Patient_ID_int = @patientId";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return Ok(new
                                {
                                    id = reader.GetInt32(0),
                                    fullName = reader.GetString(1),
                                    phone = reader.IsDBNull(2) ? null : reader.GetString(2),
                                    email = reader.IsDBNull(3) ? null : reader.GetString(3),
                                    login = reader.GetString(4)
                                });
                            }
                        }
                    }
                }

                return Ok(new { success = false, message = "Patient not found" });
            }
            catch (Exception ex)
            {
                return Ok(new { success = false, message = ex.Message });
            }
        }
    }
}