﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DentalClinicDoctor.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Введите логин")]
        public string Login { get; set; }

        [Required(ErrorMessage = "Введите пароль")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class DoctorInfo
    {
        public int DoctorId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Specialty { get; set; }
        public string PhotoUrl { get; set; }
        public string Description { get; set; }
        public double Rating { get; set; }
        public int TotalReviews { get; set; }
        public int TotalHearts { get; set; }
    }

    public class Appointment
    {
        public int AppointmentId { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public string PatientName { get; set; }
        public string PatientPhone { get; set; }
        public string ServiceName { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
        public int PatientId { get; set; }
    }

    public class PatientInfo
    {
        public int PatientId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime? BirthDate { get; set; }
        public string MedicalCardNumber { get; set; }
    }

    public class MedicalRecordModel
    {
        public int RecordId { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public DateTime RecordDate { get; set; }
        public string Diagnosis { get; set; }
        public string Prescriptions { get; set; }
        public string Recommendations { get; set; }
        public string GuaranteeInfo { get; set; }
        public int? AppointmentId { get; set; }
    }

    public class ReviewModel
    {
        public int ReviewId { get; set; }
        public string PatientName { get; set; }
        public int Grade { get; set; }
        public string Comment { get; set; }
        public DateTime CreateDate { get; set; }
    }

    public class RecommendationModel
    {
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string Text { get; set; }
        public DateTime Date { get; set; }
    }

    public class TodayPatientsViewModel
    {
        public DoctorInfo Doctor { get; set; }
        public List<Appointment> TodayAppointments { get; set; }
        public int TotalAppointments { get; set; }
        public int CompletedAppointments { get; set; }
        public int PendingAppointments { get; set; }
    }

    public class DoctorRatingViewModel
    {
        public DoctorInfo Doctor { get; set; }
        public List<ReviewModel> Reviews { get; set; }
        public double AverageGrade { get; set; }
        public int HeartsCount { get; set; }
    }
}