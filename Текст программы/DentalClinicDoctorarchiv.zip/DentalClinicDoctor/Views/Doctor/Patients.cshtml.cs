using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DentalClinicDoctor.Views.Doctor
{
    public class PatientsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
