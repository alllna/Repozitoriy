using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DentalClinicDoctor.Views.Doctor
{
    public class RewiewsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
