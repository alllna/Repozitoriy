using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DentalClinicDoctor.Views.Doctor
{
    public class PatientDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
