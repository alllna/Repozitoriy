using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DentalClinicDoctor.Views.Doctor
{
    public class ScheduleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
