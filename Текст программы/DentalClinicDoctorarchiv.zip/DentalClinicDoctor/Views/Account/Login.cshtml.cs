using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DentalClinicDoctor.Views.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
