﻿using Microsoft.EntityFrameworkCore;
using DentalClinicDoctor.Models;
using System.Data.Common;
using Microsoft.Data.SqlClient;

namespace DentalClinicDoctor.Data
{
    public class ClinicDbContext : DbContext
    {
        public ClinicDbContext(DbContextOptions<ClinicDbContext> options) : base(options)
        {
        }

        // Для прямых SQL-запросов
        public DbSet<DoctorInfo> Doctors { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<PatientInfo> Patients { get; set; }
        public DbSet<MedicalRecordModel> MedicalRecords { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Настройка, чтобы EF не пытался создавать таблицы
            modelBuilder.Entity<DoctorInfo>().ToView(null);
            modelBuilder.Entity<Appointment>().ToView(null);
            modelBuilder.Entity<PatientInfo>().ToView(null);
            modelBuilder.Entity<MedicalRecordModel>().ToView(null);
        }
    }
}