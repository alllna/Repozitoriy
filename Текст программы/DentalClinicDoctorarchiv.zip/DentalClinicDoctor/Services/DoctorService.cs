﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using DentalClinicDoctor.Models;
using System.Data;

namespace DentalClinicDoctor.Services
{
    public class DoctorService
    {
        private readonly string _connectionString;

        public DoctorService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Вход врача
        public DoctorInfo Login(string login, string password)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT d.Doctor_ID_int, d.User_ID_int, 
                           d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as FullName,
                           d.specialty_varchar as Specialty,
                           d.photo_url_varchar as PhotoUrl,
                           d.description as Description,
                           ISNULL(AVG(r.grade_int * 1.0), 0) as Rating,
                           COUNT(DISTINCT r.Review_ID_int) as TotalReviews
                    FROM Doctors d
                    INNER JOIN Users u ON d.User_ID_int = u.User_ID_int
                    LEFT JOIN Rewiews r ON d.Doctor_ID_int = r.doctor_ID_int
                    WHERE u.login_varchar = @login AND u.password_hash = @password
                    GROUP BY d.Doctor_ID_int, d.User_ID_int, d.surname_varchar, d.name_varchar, 
                             d.middle_name_varchar, d.specialty_varchar, d.photo_url_varchar, d.description";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", password);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new DoctorInfo
                            {
                                DoctorId = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                FullName = reader.GetString(2),
                                Specialty = reader.GetString(3),
                                PhotoUrl = reader.IsDBNull(4) ? null : reader.GetString(4),
                                Description = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Rating = Convert.ToDouble(reader.GetDecimal(6)),
                                TotalReviews = reader.GetInt32(7)
                            };
                        }
                    }
                }
            }
            return null;
        }

        // Получить информацию о враче
        public DoctorInfo GetDoctorInfo(int doctorId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT d.Doctor_ID_int, d.User_ID_int, 
                           d.surname_varchar + ' ' + d.name_varchar + ' ' + ISNULL(d.middle_name_varchar, '') as FullName,
                           d.specialty_varchar as Specialty,
                           d.photo_url_varchar as PhotoUrl,
                           d.description as Description,
                           ISNULL(AVG(r.grade_int * 1.0), 0) as Rating,
                           COUNT(DISTINCT r.Review_ID_int) as TotalReviews,
                           (SELECT COUNT(*) FROM Rewiews WHERE doctor_ID_int = d.Doctor_ID_int AND grade_int >= 4) as HeartsCount
                    FROM Doctors d
                    LEFT JOIN Rewiews r ON d.Doctor_ID_int = r.doctor_ID_int
                    WHERE d.Doctor_ID_int = @doctorId
                    GROUP BY d.Doctor_ID_int, d.User_ID_int, d.surname_varchar, d.name_varchar, 
                             d.middle_name_varchar, d.specialty_varchar, d.photo_url_varchar, d.description";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new DoctorInfo
                            {
                                DoctorId = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                FullName = reader.GetString(2),
                                Specialty = reader.GetString(3),
                                PhotoUrl = reader.IsDBNull(4) ? null : reader.GetString(4),
                                Description = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Rating = Convert.ToDouble(reader.GetDecimal(6)),
                                TotalReviews = reader.GetInt32(7),
                                TotalHearts = reader.GetInt32(8)
                            };
                        }
                    }
                }
            }
            return null;
        }

        // Получить записи на сегодня
        public List<Appointment> GetTodayAppointments(int doctorId)
        {
            var appointments = new List<Appointment>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT a.Appointment_ID_int, a.appointment_date, a.start_time_time,
                           p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as PatientName,
                           p.phone_varchar as PatientPhone,
                           s.title_varchar as ServiceName,
                           s.price_decimal as Price,
                           a.status_varchar as Status,
                           a.notes as Notes,
                           p.Patient_ID_int as PatientId
                    FROM Appointments a
                    INNER JOIN Patient p ON a.patient_ID_int = p.Patient_ID_int
                    INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                    WHERE a.doctor_ID_int = @doctorId 
                      AND a.appointment_date = CAST(GETDATE() AS DATE)
                      AND a.status_varchar != 'cancelled'
                    ORDER BY a.start_time_time";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            appointments.Add(new Appointment
                            {
                                AppointmentId = reader.GetInt32(0),
                                Date = reader.GetDateTime(1),
                                StartTime = reader.GetTimeSpan(2),
                                PatientName = reader.GetString(3),
                                PatientPhone = reader.IsDBNull(4) ? null : reader.GetString(4),
                                ServiceName = reader.GetString(5),
                                Price = reader.GetDecimal(6),
                                Status = reader.GetString(7),
                                Notes = reader.IsDBNull(8) ? null : reader.GetString(8),
                                PatientId = reader.GetInt32(9)
                            });
                        }
                    }
                }
            }
            return appointments;
        }

        // Получить расписание врача на неделю
        public List<Appointment> GetDoctorSchedule(int doctorId, DateTime startDate)
        {
            var appointments = new List<Appointment>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT a.Appointment_ID_int, a.appointment_date, a.start_time_time,
                           p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as PatientName,
                           p.phone_varchar as PatientPhone,
                           s.title_varchar as ServiceName,
                           s.price_decimal as Price,
                           a.status_varchar as Status,
                           a.notes as Notes,
                           p.Patient_ID_int as PatientId
                    FROM Appointments a
                    INNER JOIN Patient p ON a.patient_ID_int = p.Patient_ID_int
                    INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                    WHERE a.doctor_ID_int = @doctorId 
                      AND a.appointment_date >= @startDate
                      AND a.appointment_date < DATEADD(day, 7, @startDate)
                      AND a.status_varchar != 'cancelled'
                    ORDER BY a.appointment_date, a.start_time_time";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);
                    cmd.Parameters.AddWithValue("@startDate", startDate);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            appointments.Add(new Appointment
                            {
                                AppointmentId = reader.GetInt32(0),
                                Date = reader.GetDateTime(1),
                                StartTime = reader.GetTimeSpan(2),
                                PatientName = reader.GetString(3),
                                PatientPhone = reader.IsDBNull(4) ? null : reader.GetString(4),
                                ServiceName = reader.GetString(5),
                                Price = reader.GetDecimal(6),
                                Status = reader.GetString(7),
                                Notes = reader.IsDBNull(8) ? null : reader.GetString(8),
                                PatientId = reader.GetInt32(9)
                            });
                        }
                    }
                }
            }
            return appointments;
        }

        // Получить всех пациентов врача
        public List<PatientInfo> GetDoctorPatients(int doctorId)
        {
            var patients = new List<PatientInfo>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT DISTINCT 
                           p.Patient_ID_int, p.User_ID_int,
                           p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as FullName,
                           p.phone_varchar, p.email_varchar, p.birth_date_date,
                           'Номер_' + CAST(p.Patient_ID_int AS VARCHAR) as MedicalCardNumber
                    FROM Appointments a
                    INNER JOIN Patient p ON a.patient_ID_int = p.Patient_ID_int
                    WHERE a.doctor_ID_int = @doctorId
                    ORDER BY FullName";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            patients.Add(new PatientInfo
                            {
                                PatientId = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                FullName = reader.GetString(2),
                                Phone = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Email = reader.IsDBNull(4) ? null : reader.GetString(4),
                                BirthDate = reader.IsDBNull(5) ? null : reader.GetDateTime(5),
                                MedicalCardNumber = reader.GetString(6)
                            });
                        }
                    }
                }
            }
            return patients;
        }

        // Получить историю посещений пациента
        public List<Appointment> GetPatientHistory(int doctorId, int patientId)
        {
            var appointments = new List<Appointment>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT a.Appointment_ID_int, a.appointment_date, a.start_time_time,
                           p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as PatientName,
                           p.phone_varchar as PatientPhone,
                           s.title_varchar as ServiceName,
                           s.price_decimal as Price,
                           a.status_varchar as Status,
                           a.notes as Notes,
                           p.Patient_ID_int as PatientId
                    FROM Appointments a
                    INNER JOIN Patient p ON a.patient_ID_int = p.Patient_ID_int
                    INNER JOIN Servicees s ON a.servicee_ID_int = s.Servicee_ID_int
                    WHERE a.doctor_ID_int = @doctorId AND a.patient_ID_int = @patientId
                    ORDER BY a.appointment_date DESC";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);
                    cmd.Parameters.AddWithValue("@patientId", patientId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            appointments.Add(new Appointment
                            {
                                AppointmentId = reader.GetInt32(0),
                                Date = reader.GetDateTime(1),
                                StartTime = reader.GetTimeSpan(2),
                                PatientName = reader.GetString(3),
                                PatientPhone = reader.IsDBNull(4) ? null : reader.GetString(4),
                                ServiceName = reader.GetString(5),
                                Price = reader.GetDecimal(6),
                                Status = reader.GetString(7),
                                Notes = reader.IsDBNull(8) ? null : reader.GetString(8),
                                PatientId = reader.GetInt32(9)
                            });
                        }
                    }
                }
            }
            return appointments;
        }

        // Получить медицинскую карту пациента
        public List<MedicalRecordModel> GetMedicalRecords(int doctorId, int patientId)
        {
            var records = new List<MedicalRecordModel>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT mr.MedicalRecord_ID_int, mr.patient_ID_int,
                           p.surname_varchar + ' ' + p.name_varchar + ' ' + ISNULL(p.middle_name_varchar, '') as PatientName,
                           mr.record_date, mr.diagnosis, mr.prescriptions, 
                           mr.recommendations, mr.guarantee_info, mr.appointment_ID
                    FROM MedicalRecords mr
                    INNER JOIN Patient p ON mr.patient_ID_int = p.Patient_ID_int
                    WHERE mr.doctor_ID_int = @doctorId AND mr.patient_ID_int = @patientId
                    ORDER BY mr.record_date DESC";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);
                    cmd.Parameters.AddWithValue("@patientId", patientId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            records.Add(new MedicalRecordModel
                            {
                                RecordId = reader.GetInt32(0),
                                PatientId = reader.GetInt32(1),
                                PatientName = reader.GetString(2),
                                RecordDate = reader.GetDateTime(3),
                                Diagnosis = reader.IsDBNull(4) ? null : reader.GetString(4),
                                Prescriptions = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Recommendations = reader.IsDBNull(6) ? null : reader.GetString(6),
                                GuaranteeInfo = reader.IsDBNull(7) ? null : reader.GetString(7),
                                AppointmentId = reader.IsDBNull(8) ? null : reader.GetInt32(8)
                            });
                        }
                    }
                }
            }
            return records;
        }

        // Добавить/обновить медицинскую карту (исправленная версия с MERGE)
        public bool SaveMedicalRecord(MedicalRecordModel record, int doctorId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Используем MERGE для безопасного обновления или вставки
                // Это полностью исключает ошибку уникальности
                string query = @"
                    MERGE INTO MedicalRecords AS target
                    USING (SELECT @patientId AS PatientId, @doctorId AS DoctorId, @appointmentId AS AppointmentId) AS source
                    ON (target.patient_ID_int = source.PatientId 
                        AND target.doctor_ID_int = source.DoctorId
                        AND ((target.appointment_ID = source.AppointmentId) 
                             OR (target.appointment_ID IS NULL AND source.AppointmentId IS NULL)))
                    WHEN MATCHED THEN
                        UPDATE SET 
                            diagnosis = @diagnosis,
                            prescriptions = @prescriptions,
                            recommendations = @recommendations,
                            guarantee_info = @guaranteeInfo,
                            record_date = GETDATE()
                    WHEN NOT MATCHED THEN
                        INSERT (patient_ID_int, doctor_ID_int, appointment_ID, record_date, diagnosis, prescriptions, recommendations, guarantee_info)
                        VALUES (@patientId, @doctorId, @appointmentId, GETDATE(), @diagnosis, @prescriptions, @recommendations, @guaranteeInfo);";

                using (var cmd = new SqlCommand(query, connection))
                {
                    // Добавляем параметры с правильной обработкой NULL
                    cmd.Parameters.AddWithValue("@patientId", record.PatientId);
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);

                    // Правильная обработка nullable типов
                    if (record.AppointmentId.HasValue)
                        cmd.Parameters.AddWithValue("@appointmentId", record.AppointmentId.Value);
                    else
                        cmd.Parameters.AddWithValue("@appointmentId", DBNull.Value);

                    // Обработка текстовых полей (могут быть NULL)
                    cmd.Parameters.AddWithValue("@diagnosis", record.Diagnosis ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@prescriptions", record.Prescriptions ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@recommendations", record.Recommendations ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@guaranteeInfo", record.GuaranteeInfo ?? (object)DBNull.Value);

                    // MERGE возвращает количество затронутых строк
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }

        // Отметить прием как выполненный
        public bool MarkAppointmentCompleted(int appointmentId, int doctorId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    UPDATE Appointments 
                    SET status_varchar = 'completed' 
                    WHERE Appointment_ID_int = @appointmentId AND doctor_ID_int = @doctorId";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@appointmentId", appointmentId);
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Получить отзывы о враче
        public List<ReviewModel> GetDoctorReviews(int doctorId)
        {
            var reviews = new List<ReviewModel>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                    SELECT r.Review_ID_int, p.surname_varchar + ' ' + p.name_varchar as PatientName,
                           r.grade_int, r.comment_varchar, r.create_at_datetime
                    FROM Rewiews r
                    INNER JOIN Patient p ON r.patient_ID_int = p.Patient_ID_int
                    WHERE r.doctor_ID_int = @doctorId
                    ORDER BY r.create_at_datetime DESC";

                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@doctorId", doctorId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reviews.Add(new ReviewModel
                            {
                                ReviewId = reader.GetInt32(0),
                                PatientName = reader.GetString(1),
                                Grade = reader.GetInt32(2),
                                Comment = reader.IsDBNull(3) ? null : reader.GetString(3),
                                CreateDate = reader.GetDateTime(4)
                            });
                        }
                    }
                }
            }
            return reviews;
        }

        // Добавить рекомендацию пациенту (исправленная версия)
        public bool AddRecommendation(int doctorId, int patientId, string recommendation)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Проверяем существование записи без привязки к приему
                        string checkQuery = @"
                            SELECT MedicalRecord_ID_int 
                            FROM MedicalRecords 
                            WHERE patient_ID_int = @patientId 
                              AND doctor_ID_int = @doctorId 
                              AND appointment_ID IS NULL";

                        int existingRecordId = 0;

                        using (var checkCmd = new SqlCommand(checkQuery, connection, transaction))
                        {
                            checkCmd.Parameters.AddWithValue("@patientId", patientId);
                            checkCmd.Parameters.AddWithValue("@doctorId", doctorId);

                            var result = checkCmd.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                existingRecordId = Convert.ToInt32(result);
                            }
                        }

                        if (existingRecordId > 0)
                        {
                            // Обновляем существующую запись
                            string updateQuery = @"
                                UPDATE MedicalRecords 
                                SET recommendations = ISNULL(recommendations, '') + CHAR(13) + CHAR(10) + @recommendation,
                                    record_date = GETDATE()
                                WHERE MedicalRecord_ID_int = @recordId";

                            using (var updateCmd = new SqlCommand(updateQuery, connection, transaction))
                            {
                                updateCmd.Parameters.AddWithValue("@recordId", existingRecordId);
                                updateCmd.Parameters.AddWithValue("@recommendation", recommendation);
                                updateCmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            // Создаем новую запись
                            string insertQuery = @"
                                INSERT INTO MedicalRecords (patient_ID_int, doctor_ID_int, recommendations, record_date)
                                VALUES (@patientId, @doctorId, @recommendation, GETDATE())";

                            using (var insertCmd = new SqlCommand(insertQuery, connection, transaction))
                            {
                                insertCmd.Parameters.AddWithValue("@patientId", patientId);
                                insertCmd.Parameters.AddWithValue("@doctorId", doctorId);
                                insertCmd.Parameters.AddWithValue("@recommendation", recommendation);
                                insertCmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        return true;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
    }
}